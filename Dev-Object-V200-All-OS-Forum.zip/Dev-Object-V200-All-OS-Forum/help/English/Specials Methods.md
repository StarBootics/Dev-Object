## Specials Methods ##

Among the basic methods, we have Increment, Decrement, Looping, Scrolling and finally Toggle. 

In order to generate these methods, just define a member of the object and add in the form of a comment **Special**: followed by the name of the desired method(s).

Limitation about the **Toggle** method : only works with integer types, i.e. : **.a**, **.b**, **.c**, **.u**, **.w**, **.i**, **.l** or **.q**

---

This document was last modified on April 13^th^, 2022 at 13h07 by Guillaume Saumure. 














