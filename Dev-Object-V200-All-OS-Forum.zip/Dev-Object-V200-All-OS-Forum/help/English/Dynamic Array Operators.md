## Dynamic Array Operators ##

Among the operators for dynamic array, we have :

- Sort
- Linear search
- Binary search
- Randomize
- ReDim
- Size

Note that the operators **Sort**, **Linear search** and **Binary search** only work on arrays with only one dimension and standard types. If the array contains objects, the sorting and searching commands must be implemented manually.

---

This document was last modified on April 13^th^, 2022 at 11h53 by Guillaume Saumure.














