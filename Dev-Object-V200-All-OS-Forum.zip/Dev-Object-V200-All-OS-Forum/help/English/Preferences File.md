## Preferences File ##

Among the operators for preferences file, we have :

- Read/Write a group
- Create/Open a file

Note that if an object contains other objects, the operators **Read/Write a group** must be modified manually.

---

This document was last modified on April 13^st^, 2022 at 13h06 by Guillaume Saumure. 














