## Linked list Operators ##

Among the operators for linked list, we have :

- Sort
- Linear search
- Binary search
- Randomize
- Add element
- Add element Ex
- Insert element
- Insert element Ex
- Select element
- First element
- Last element
- Previous element
- Next element
- Delete element
- Reset
- Clear
- Index
- Size
- Merge

Note that the operators **Sort**, **Linear search** and **Binary search** only work if the list contains standard types. If the list contains objects, the sorting and search operators must be implemented manually.

---

This document was last modified on April 13^th^, 2022 at 11h59 by Guillaume Saumure. 
 














