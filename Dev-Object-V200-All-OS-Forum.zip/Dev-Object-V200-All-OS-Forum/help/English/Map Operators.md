## Map Operators ##

Among the operators for map, we have :

- Add element
- Add element Ex
- Clear
- Size
- Reset
- Delete element
- Find element
- Next element
- Key

Note that these operators work with maps of all standard types as well as objects.

---

This document was last modified on April 13^th^, 2022 at 12h35 by Guillaume Saumure. 
 














