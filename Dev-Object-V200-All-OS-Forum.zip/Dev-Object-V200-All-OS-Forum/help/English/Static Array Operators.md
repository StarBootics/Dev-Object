## Static Array Operators ##

Among the operators for static array, we have :

- QuickSort Ascending
- QuickSort Descending
- Linear search
- Binary search
- Fixed Queue

Note that the operators **QuickSort**, **Linear search** and **Binary search** only work on arrays of standard types. If the arrays contains objects, the sorting and searching commands must be implemented manually.

---

This document was last modified on April 13^th^, 2022 at 13h09 by Guillaume Saumure.














