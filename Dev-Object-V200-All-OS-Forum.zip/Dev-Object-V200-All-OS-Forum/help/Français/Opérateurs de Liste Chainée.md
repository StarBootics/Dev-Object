## Opérateurs de Liste chainée ##

Parmis les opérateurs de liste chainée, nous avons :

- Trier
- Fouille linénaire
- Fouille Dichotomique
- Rendre aléatoire
- Ajouter un élément
- Ajouter un élément Ex
- Insérer un élément
- Insérer un élément Ex
- Sélectionner un élément
- Premier élément
- Dernier élément
- Élément précédent
- Élément suivant
- Supprimer un élément
- Reset
- Clear
- Index
- Grandeur
- Fusionner

À noter que les opérateurs **Trier**, **Fouille linéaire** et **Fouille dichotomique** fonctionnent uniquement si la liste contient des types standard. Si la liste contient des objets, les commandes de triage et de fouille devront être implémentées manuellement.

---

Ce document à été modifié pour la dernière fois le 13-04-2022 à 11h41 par Guillaume Saumure. 














