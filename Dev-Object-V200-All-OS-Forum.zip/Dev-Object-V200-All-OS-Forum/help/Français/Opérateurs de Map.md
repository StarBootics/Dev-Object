## Opérateurs de Map ##

Parmis les opérateurs de Map, nous avons :

- Ajouter un élément
- Ajouter un élément Ex
- Clear
- Grandeur
- Reset
- Supprimer un élément
- Trouver un élément
- Élément suivant
- Clé

À noter que ces opérateurs fonctionnent avec les Map de tout types standard ainsi que des objets.

---

Ce document a été modifié pour la dernière fois le 13-04-2022 à 11h43 par Guillaume Saumure. 














