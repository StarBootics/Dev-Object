## Opérateurs de Tableau Statique ##

Parmis les opérateurs de tableau statique, nous avons :

- QuickSort Ascendant
- QuickSort Descendant
- Fouille linénaire
- Fouille Dichotomique
- File d'attente fixe

À noter que les opérateurs **QuickSort**, **Fouille linéaire** et **Fouille dichotomique** fonctionnent uniquement sur des tableaux de types standard. Si le tableau contient des objets, les commandes de triage et de fouille devront être implémentées manuellement.

---

Ce document a été modifié pour la dernière fois le 13-04-2022 à 11h45 par Guillaume Saumure. 














