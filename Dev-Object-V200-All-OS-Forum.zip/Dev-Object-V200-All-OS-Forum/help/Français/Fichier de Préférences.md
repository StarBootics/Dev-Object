## Fichier de Préférences ##

Parmis les opérateurs sur fichier de préférences, nous avons :

- Lire/Écrire un groupe
- Créer/Ouvrir un fichier

À noter que si un objet contient d'autres objets, les opérateurs **Lire/Écrire un groupe** devront être modifiés manuellement.

--------------------------------------------------------------------------------------------

Ce document a été modifié pour la dernière fois le 13-04-2022 à 13h19 par Guillaume Saumure. 














