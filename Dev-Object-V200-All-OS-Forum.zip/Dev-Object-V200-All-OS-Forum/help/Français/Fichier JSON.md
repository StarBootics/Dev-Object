## Fichier JSON ##

Parmis les opérateurs sur fichier JSON, nous avons :

- Insérer/Extraire un objet
- Sauver/Charger un fichier
- Capturer un fichier

À noter que si un objet contient d'autres objets, le générateur de code prend pour acquis que les méthodes **Insérer/Extraire un objet** ont été générées par **Dev-Object** pour ces objets.

## Limitations ##

Les tableaux dynamique multi-dimensionnels d'objets ne sont pas supportés pour le moment.

--------------------------------------------------------------------------------------------

Ce document a été modifié pour la dernière fois le 09-11-2022 à 10h52 par Guillaume Saumure. 














