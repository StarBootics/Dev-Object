## Méthodes Spéciales ##

Parmis les méthodes spéciales, nous avons **Increment**, **Decrement**, **Looping**, **Scrolling** et finalement **Toggle**. 

Afin de générer ces méthodes, il suffit de définir un membre de l'objet et d'ajouter sous la forme d'un commentaire **Special** : suivi du nom de la ou les méthodes désirées.

Limitation à propos de la méthode **Toggle** : fonctionne uniquement avec les types entiers, c'est à dire : **.a**, **.b**, **.c**, **.u**, **.w**, **.i**, **.l** ou **.q**

--------------------------------------------------------------------------------------------

Ce document a été modifié pour la dernière fois le 13-04-2022 à 11h41 par Guillaume Saumure. 














