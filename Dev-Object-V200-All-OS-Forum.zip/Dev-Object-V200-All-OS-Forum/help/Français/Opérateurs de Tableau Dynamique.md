## Opérateurs de Tableau dynamique ##

Parmis les opérateurs de tableau dynamique, nous avons :

- Trier
- Fouille linénaire
- Fouille Dichotomique
- Rendre aléatoire
- Re-Dimensionner
- Grandeur

À noter que les opérateurs **Trier**, **Fouille linéaire** et **Fouille dichotomique** fonctionnent uniquement sur des tableaux à une seule dimension et de types standard. Si le tableau contient des objets, les commandes de triage et de fouille devront être implémentées manuellement.

---

Ce document a été modifié pour la dernière fois le 13-04-2022 à 11h44 par Guillaume Saumure. 














