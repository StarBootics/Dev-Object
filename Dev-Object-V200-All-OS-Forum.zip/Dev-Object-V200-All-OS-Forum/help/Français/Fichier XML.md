## Fichier XML ##

Parmis les opérateurs sur fichier XML, nous avons :

- Noeud avec noeuds enfants
- Noeud avec attributs
- Ajouter/Collecter des attributs
- Créer/Charger un fichier
- Capturer un fichier

À noter que si un objet contient d'autres objets, le générateur de code prend pour acquis que les méthodes **Noeud avec noeuds enfants**, **Noeud avec attributs** ou **Ajouter/Collecter des attributs** ont été générées par **Dev-Object** pour ces objets.

--------------------------------------------------------------------------------------------

Ce document a été modifié pour la dernière fois le 13-04-2022 à 11h33 par Guillaume Saumure. 














